<?php $__env->startSection('title', 'Assignments List'); ?>

<?php $__env->startSection('page-title', 'Assignments List'); ?>

<?php $__env->startSection('content'); ?>

<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-10">
            <h4><?php echo e(__('This is your assignments list!')); ?> </h4>
            </div>
            <?php if($assignment_list == null): ?>
            <div class="col-lg-12 col-md-12">
                <div class="card">
                    <div class="card-header" data-background-color="blue">
                        <h4 class="title">Assignments</h4>
                    </div>
                    <div class="card-content">
                        <h4>There is no assignments!</h4>  
                    </div>
                </div>
            </div>
            <?php else: ?>
                <?php
                $counter = 0;
                ?>
                    <?php $__currentLoopData = $student_class; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($assignment_number[$counter]=="yes"): ?>
                                <div class="col-lg-12 col-md-12">
                                    <div class="card">
                                        <div class="card-header" data-background-color="blue">
                                            <h4 class="title"><?php echo e($class->class_name); ?> Assignments</h4>
                                            <!--<p class="category">Latest assignments posted on 15th September, 2020</p>-->
                                        </div>
                                        
                                <div class="card-content table-responsive">
                                    <table class="table table-hover">
                                        <thead class="text-warning">
                                            <th>Assignment Name</th>
                                            <th>Final Report</th>
                                            <th>Peer Marks</th>
                                        </thead> 
                            <?php endif; ?>
                
                                    <?php $__currentLoopData = $assignment_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($list->class_id == $class->id): ?>
                                            <tbody>
                                                <tr>
                                                    <?php $__currentLoopData = $assignment_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assignment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($list->assignment_id == $assignment->id): ?>
                                                        <td><?php echo e($assignment->assignment_name); ?></td>
                                                    <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($list->submit_status == 'completed'): ?>
                                                        <td>Completed</td>
                                                    <?php else: ?>
                                                        <td>Not Completed</td>
                                                    <?php endif; ?>

                                                    <?php if($list->evaluate_status == 'completed'): ?>
                                                        <td>Completed</td>
                                                    <?php else: ?>
                                                        <td>Not Completed</td>
                                                    <?php endif; ?>
                                                </tr>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                <?php
                $counter = $counter + 1;
                ?>
                
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.student.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Peer-Evaluation-System-main2\resources\views/layouts/student/assignmentslist.blade.php ENDPATH**/ ?>