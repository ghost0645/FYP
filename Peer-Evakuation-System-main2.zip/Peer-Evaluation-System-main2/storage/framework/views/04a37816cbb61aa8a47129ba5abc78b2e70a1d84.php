<?php $__env->startSection('title', 'User Profile'); ?>

<?php $__env->startSection('page-title', 'User Profile'); ?>

<?php $__env->startSection('content'); ?>

<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-10">
            <h4><?php echo e(__('This is your user profile!')); ?> </h4>
            </div>
            
            <div class="col-lg-12 col-md-12">
                <div class="card">
                    <div class="card-header" data-background-color="green">
                        <h4 class="title">User Information</h4>
                    </div>
                    <div class="card-content">
                    </br>
                    <?php if(session('success')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php elseif(session('error')): ?>
                        <div class="alert alert-danger" role="alert">
                            <?php echo e(session('error')); ?>

                        </div>
                    <?php endif; ?>
                        <h4 class="title">Name<div class="btn-group pull-right"></h4>
                        <p class="category"><?php echo e(Auth::user()->name); ?></p>
                        
                    </div>
                    <div class="card-content">
                        <h4 class="title">Email<div class="btn-group pull-right"></h4>
                        <p class="category"><?php echo e(Auth::user()->email); ?></p><div class="btn-group pull-right">
                        <a href="/student/user-information-edit" class="btn btn-primary filter-button">Edit</a> 
                        </div>
                    </div> 
                    
                </div>
            </div>

           
            <div class="col-lg-12 col-md-12">
                <div class="card">
                    <div class="card-header" data-background-color="orange">
                        <h4 class="title">Password</h4>
                    </div>
                    <div class="card-content">
                    <h4 class="title">Password<div class="btn-group pull-right"></h4>
                        <p class="category">*******</p>
                        <div class="btn-group pull-right">
                        <a href="/student/user-password-edit" class="btn btn-primary filter-button">Edit</a> 
                        </div>
                    </div>
                </div>
            </div>
            

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.student.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Peer-Evaluation-System-main2\resources\views/layouts/student/userprofile.blade.php ENDPATH**/ ?>