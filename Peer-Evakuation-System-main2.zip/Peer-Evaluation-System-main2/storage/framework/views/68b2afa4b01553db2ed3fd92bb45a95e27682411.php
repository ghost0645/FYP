

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('page-title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>

<div class="content">
    <div class="container-fluid">
        <div class="row">

            <div class="col-md-10">
            <h4>Welcome back <?php echo e(Auth::user()->name); ?> !</h4>
                <div class="card card-stats">
                    <div class="card-header" data-background-color="grey">
                        <i class="material-icons">assignment</i>
                    </div>
                    <div class="card-content">
                        </br>



                        <div class="form-group  is-empty">
                            </br>
                            <?php if(session('success')): ?>
                                <div class="alert alert-success text-justify" role="alert">
                                    <?php echo e(session('success')); ?>

                                </div>
                            <?php elseif(session('error')): ?>
                                <div class="alert alert-danger text-justify" role="alert">
                                    <?php echo e(session('error')); ?>

                                </div>
                            <?php endif; ?>

                          
                            
                        <form action="/lecturer/viewclassdetail/{id}/createassignment" method="POST">
                            
                                                
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="class_id" class="form-control" value="<?php echo e($class_detail->id); ?>"></input>
                            <input type="hidden" name="class_name" class="form-control" value="<?php echo e($class_detail->class_name); ?>"></input>
                            <input type="text" name="assignment_name" class="form-control" placeholder="Assignment Name"></input>
                            <input type="text" name="assignment_description" class="form-control" placeholder="Assignment Description"></input>
            
                            <br>
                            <div>
                                <div style="float:left; position:relative;">
                                    <h6 style="margin-right:5em; width:100%; text-align:left;">Final Report Due Date & Time</h6>
                                    <input style="margin-right:5em; float:left; position:relative;" type="datetime-local" name="final_report_due_date" class="form-control" placeholder="Final Report Due Date"></input>
                                    <br>
                                    <h6 style="margin-right:5em; text-align:left;">Peer Marks Due Date & Time</h6>
                                    <input style="margin-right:5em; float:left; position:relative;" type="datetime-local" name="peer_marks_due_date" class="form-control" placeholder="Peer Marks Due Date"></input>
                                    <br>
                               </div>
                                
                               <div style="float:left; position:relative;">
                                    <h6 style="text-align:left; margin-left:5em">Final Report Grace Period</h6>
                                    <input style="margin-left:5em; float:left; position:relative;" type="datetime-local" name="final_report_grace_period" class="form-control" placeholder="Final Report Grace Period"></input>
                                    <br>
                                    <h6 style="text-align:left; margin-left:5em">Peer Marks Grace Period</h6>
                                    <input style="margin-left:5em; float:left; position:relative;" type="datetime-local" name="peer_marks_grace_period" class="form-control" placeholder="Peer Marks Grace Period"></input>
                                    <br><br>
                                </div>                     
                            </div>
                            
                            
                </div>
            </div>         
            
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.lecturer.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Peer-Evaluation-System-main2\resources\views/layouts/lecturer/editassignment.blade.php ENDPATH**/ ?>