<?php $__env->startSection('page-title', 'Login'); ?>

<?php $__env->startSection('content'); ?>
<style>
		
	html {
		background-image: url("<?php echo e(asset('img/cover1.jpg')); ?>");
		background-size: cover;
	}

</style>

<div class="col-lg-6 col-md-12">
<div class="card card-signup" style="margin-left: 50%;margin-top: 15%;">
	<div class="header header-primary text-center"> <h4><?php echo e(isset($url) ? ucwords($url) : ""); ?> <?php echo e(__('Login')); ?></h4></div>
		<div class="card-body">
			<?php if(isset($url)): ?>
			
			<form method="POST" action='<?php echo e(url("login/$url")); ?>' aria-label="<?php echo e(__('Login')); ?>">
			
			<?php endif; ?>
				<?php echo csrf_field(); ?>
		
		<p class="text-divider">Please provide your email and password</p>
		<div class="content">
			</br>
			<?php if(session('success')): ?>
					<div class="alert alert-success text-justify" role="alert">
						<?php echo e(session('success')); ?>

					</div>
			<?php elseif(session('error')): ?>
				<div class="alert alert-danger text-justify" role="alert">
					<?php echo e(session('error')); ?>

				</div>
			<?php endif; ?>
			<div class="input-group">
				<span class="input-group-addon">
					<i class="material-icons">email</i>
				</span>
				<input id="email" type="email" placeholder="Email..." class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>

				<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
					<span class="invalid-feedback" role="alert">
						<strong><?php echo e($message); ?></strong>
					</span>
				<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			</div>
			</br>
			<div class="input-group">
				<span class="input-group-addon">
					<i class="material-icons">lock_outline</i>
				</span>
				<input id="password" type="password" placeholder="Password..." class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="current-password">

				<?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
					<span class="invalid-feedback" role="alert">
						<strong><?php echo e($message); ?></strong>
					</span>
				<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			</div>
			</br><!--
			<div class="checkbox">
				<label>
				<input class="form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
					<?php echo e(__('Remember Me')); ?>

				</label>
			</div> -->
		</div>
			<div class="footer text-center">
				<button type="submit" class="btn btn-primary btn-round"><?php echo e(__('Login')); ?></button>
				<hr>
				<a href="<?php echo e(url('/')); ?>" class="btn btn-info btn-simple">Home</a>
				<a href="/register/<?php echo e($url); ?>" class="btn btn-info btn-simple"><?php echo e(__('Register')); ?></a>
				<?php if(Route::has('password.request')): ?>
					<a class="btn btn-info btn-simple" href="<?php echo e(route('password.request')); ?>">
						<?php echo e(__('Forgot Your Password?')); ?>

					</a>
				<?php endif; ?>
			</div>
			</form>
			
		</div>
	</div>		
</div></div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Peer-Evaluation-System-main2\resources\views/auth/login.blade.php ENDPATH**/ ?>