<?php $__env->startSection('page-title', 'Register a new account'); ?>

<?php $__env->startSection('content'); ?>

<style>
		
	html {
		background-image: url("<?php echo e(asset('img/cover1.jpg')); ?>");
		background-size: cover;
	}

</style>

<div class="col-lg-6 col-md-12">
<div class="card card-signup" style="margin-left: 50%;margin-top: 5%;">
	<div class="header header-primary text-center"> <h4><?php echo e(isset($url) ? ucwords($url) : ""); ?> <?php echo e(__('Register')); ?></h4></div>

	<div class="card-body">
		<?php if(isset($url)): ?>
		<form method="POST" action='<?php echo e(url("register/$url")); ?>' aria-label="<?php echo e(__('Register')); ?>">
		
		<?php endif; ?>
			<?php echo csrf_field(); ?>
		
		<p class="text-divider">Please fill the form bellow</p>
		<div class="content">

			<div class="form-group <?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
				<div class="input-group">
					<span class="input-group-addon">
						<i class="material-icons">face</i>
					</span>
					<input id="name" type="text" placeholder="Name..." class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus>
					<?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						<span class="invalid-feedback" role="alert">
							<strong><?php echo e($message); ?></strong>
						</span>
					<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				</div>
			</div>

			<div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
				<div class="input-group">
					<span class="input-group-addon">
						<i class="material-icons">email</i>
					</span>
					<input id="email" type="email" placeholder="Email..." class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email">
					<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						<span class="invalid-feedback" role="alert">
							<strong><?php echo e($message); ?></strong>
						</span>
					<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				</div>
			</div>

			<div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
				<div class="input-group">
					<span class="input-group-addon">
						<i class="material-icons">lock_outline</i>
					</span>
					<input id="password" type="password" placeholder="Password..." class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="new-password">
					<?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						<span class="invalid-feedback" role="alert">
							<strong><?php echo e($message); ?></strong>
						</span>
					<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				</div>
			</div>

			<div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
				<div class="input-group">
					<span class="input-group-addon">
						<i class="material-icons">lock_outline</i>
					</span>
					<input id="password-confirm" type="password" placeholder="Repeat Password..." class="form-control" name="password_confirmation" required autocomplete="new-password">
				</div>
			</div>

		</div>
			<div class="footer text-center">
				<button type="submit" class="btn btn-primary btn-round"><?php echo e(__('Register')); ?></button>
				<hr>
				<a href="<?php echo e(url('/')); ?>" class="btn btn-info btn-simple">Home</a>
				Already have an account? <a href="/login/<?php echo e($url); ?>" class="btn btn-info btn-simple"><?php echo e(__('Login')); ?></a>
			</div>
		</form>
	</div>
</div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Peer-Evaluation-System-main2\resources\views/auth/register.blade.php ENDPATH**/ ?>