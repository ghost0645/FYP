<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('page-title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>

<div class="content">
    <div class="container-fluid">
        <div class="row">

            <div class="col-md-8">
            <h4>Welcome back <?php echo e(Auth::user()->name); ?>!</h4>
                <div class="card card-stats">
                    <div class="card-header" data-background-color="orange">
                        <i class="material-icons">category</i>
                    </div>
                    <div class="card-content">
                        </br>
                        </br>
                        </br>
                        <?php if(session('success')): ?>
                            <div class="alert alert-success text-justify" role="alert">
                                <?php echo e(session('success')); ?>

                            </div>
                        <?php elseif(session('error')): ?>
                            <div class="alert alert-danger text-justify" role="alert">
                                <?php echo e(session('error')); ?>

                            </div>
                        <?php endif; ?>
                        <form action="/student" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="text" name="class_code" style="width: 80%; margin-bottom: -3%;"class="form-control" placeholder="Class Code...">
                        
                        <button type="submit" class="btn btn-primary filter-button" style="margin-right: 5%; margin-top: -9%; margin-bottom: -5%;">Join</button> 
                        
                        </form>
                        
                    </div>
                    <div class="card-footer">
                        <div class="stats">
                        <i class="material-icons">info</i> Enter class code provided by lecturer to join new class
                        </div>
                    </div>
                </div>
            </div>

            <?php if($student_class!=null): ?>
                <?php $__currentLoopData = $student_class; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                    <div class="row">
                        <div class="col-md-8" style="margin-left: 0.5%;">
                            <div class="card">
                                <div class="card-header card-chart" data-background-color="green">
                                    <div class="ct-chart" id="dailySalesChart"></div>
                                </div>
                                <div class="card-content">
                                    <a href="/student/<?php echo e($class->class_name); ?>/<?php echo e($class->id); ?>"><h4><?php echo e($class->class_name); ?></h4></a>
                                    <p class="category"><?php echo e($class->lecturer_name); ?></p>
                                </div>
                                <!--
                                <div class="card-footer">
                                    <div class="stats">
                                        <i class="material-icons">access_time</i> updated 4 minutes ago
                                    </div>
                                </div>-->
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
            <div class="row">
                <div class="col-md-10">
                    <div class="card">
                    <div class="card-content">
                        <h4>You have not add any classes yet!</h4>  
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>
            
            

            
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.student.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Peer-Evaluation-System-main2\resources\views//student.blade.php ENDPATH**/ ?>