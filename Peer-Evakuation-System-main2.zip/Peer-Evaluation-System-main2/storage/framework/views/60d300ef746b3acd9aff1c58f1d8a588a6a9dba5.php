

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('page-title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>

<div class="content">
    <div class="container-fluid">
        <div class="row">

            <div class="col-md-10">
            <h4>Welcome back <?php echo e(Auth::user()->name); ?> !</h4>
                <div class="card card-stats">
                    <div class="card-header" data-background-color="orange">
                        <i class="material-icons">category</i>
                    </div>
                    <div class="card-content">
                        </br>
                        <div class="form-group  is-empty">
                            </br>
                            <?php if(session('success')): ?>
                                <div class="alert alert-success text-justify" role="alert">
                                    <?php echo e(session('success')); ?>

                                </div>
                            <?php elseif(session('error')): ?>
                                <div class="alert alert-danger text-justify" role="alert">
                                    <?php echo e(session('error')); ?>

                                </div>
                            <?php endif; ?>
                            <form action="/lecturer/createclass" method="POST">
                            <?php echo csrf_field(); ?>
                            <input type="text" name="class_code" class="form-control" placeholder="class code"></input>
                            <input type="text" name="class_name" class="form-control" placeholder="class name"></input>
                            


                            <div class="btn-group">
                                <button type="submit" class="btn btn-primary filter-button">Create</button> 
                            </div> 
                            </form>
                        </div>
                    </div>
                    <div class="card-footer">
                       
                    </div>
                </div>
            </div>

           
            
            
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.lecturer.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Peer-Evaluation-System-main2\resources\views/layouts/lecturer/createclass.blade.php ENDPATH**/ ?>