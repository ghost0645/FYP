

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('page-title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>

<div class="content">
    <div class="container-fluid">
        <div class="row">

            <div class="col-md-10">

            

             <h4>Welcome to <?php echo e($class_detail->class_name); ?>! &nbsp&nbsp&nbsp Class Code : <?php echo e($class_detail->class_code); ?></h4>
                <h4><b>Class Join Code : <?php echo e($class_detail->class_join_code); ?></b></h4>
                

                <div class="card card-stats">

                    <div class="card-header" data-background-color="blue">
                        <i class="material-icons">add</i>
                        <a href ="/lecturer/viewclassdetail/<?php echo e($class_detail->id); ?>/createassignment"><h5> Create Assignment</h5></a>
                    </div>

                    <div class="card-header" data-background-color="blue">
                        <i class="material-icons">people</i>
                        <a href ="/lecturer/viewclassdetail/<?php echo e($class_detail->id); ?>/viewstudentlist"><h5>List of Students</h5></a>
                    </div>

                </div>

                <br>

            <?php $__currentLoopData = $assignment_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div>
                <div class="card card-stats">

                <div class="card-header" data-background-color="green">
                        <i class="material-icons">assignment</i>
                    <div>
                        <h6><?php echo e($i->assignment_name); ?></h6>
                        <h6>Final Report Due Date : <?php echo e($i->final_report_due_date); ?></h6>
                        <h6>Peer Marks Due Date : <?php echo e($i->peer_marks_due_date); ?></h6>
                        
                    </div>
                    
                       
                </div>
                <div>
                        <button class="btn btn-info">Edit Assignment</button>
                        <button class="btn btn-info">Edit Rubric </button> 
                        <button class="btn btn-info"><a href="/lecturer/viewclassdetail/<?php echo e($class_detail->id); ?>/viewassignmentdetail/<?php echo e($i->id); ?>" style="color:white;">View Detail </a></button>
                        <button class="btn btn-danger"><a href="/lecturer/viewclassdetail/<?php echo e($class_detail->id); ?>/deleteassignment/<?php echo e($i->id); ?>">Remove Assignment</a></button> 
                        
                </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
            
        
            
            
            </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.lecturer.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Peer-Evaluation-System-main2\resources\views/layouts/lecturer/viewclassdetail.blade.php ENDPATH**/ ?>