

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('page-title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>

<div class="content">
    <div class="container-fluid">
        <div class="row">

            <div class="col-md-10">
            <h4>List Of Classes Created</h4>
                <div class="card card-stats">
                    <div class="card-header" data-background-color="green">
                        <i class="material-icons">class</i>
                    </div>
                    <div class="card-content">
                        </br>
                     <div>
                            <table class ="table table-bordered">
                                <tr>
                                    <th>Class Code</th>
                                    <th>Class Name</th>
                                    <th>Class Join Code </th>
                                </tr>
                 
                        

                        <?php $__currentLoopData = $class_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                            <tr>
                                <td><?php echo e($i-> class_code); ?></td>
                                <td><?php echo e($i-> class_name); ?></td>
                                <td><?php echo e($i-> class_join_code); ?></td>
                                <td><a href="/lecturer/viewclassdetail/<?php echo e($i->id); ?>">view class</a></td>
                            </tr>
                            
                    
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </table>


                     </div>
                        
                        
                    </div>
                    <div class="card-footer">
                       
                    </div>
                </div>
            </div>

           
            
            
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.lecturer.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Peer-Evaluation-System-main2\resources\views/layouts/lecturer/viewclass.blade.php ENDPATH**/ ?>