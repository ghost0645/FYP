

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('page-title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>

<?php $__currentLoopData = $assignment_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 <?php echo e($i->assignment_name); ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<div class="content">
    <div class="container-fluid">
        <div class="row">

    

            <!--------------->

            <div class="col-md-7">
                <div class="card card-stats">
                    <div class="card-header" data-background-color="grey">
                        <h6>Student Submission Status</h6>
                    </div>
                    <div class="card-content" >
                    <br>
                    <br>
                    <br>
                    
                    <table class="table table-bordered">
                    <tr>
                        <th>Student List</th>
                        <th>Final Report</th>
                        <th>Peer Marks</th>
                        <th>Status</th>
                    </tr>
                    </table>
                    </div>
                </div>
            </div>
            
            <!--------------->
            <div class="content">
            <div class="col-md-4">
                <div class="card card-stats">
                    <div class="card-header" data-background-color="grey">
                        <h6>Action Panel</h6>
                    </div>
                    <div class="card-footer" >
                        <br>
                        <br>
                        <br>
                        <button class="btn btn-info">Peer Evaluator<br> Allocation</button>
                        <button class="btn btn-info">View Finalized <br> Grade</button> 
                        <button class="btn btn-info">View Grade <br> Appeal </button> 
                    </div>

                </div>
            </div>
            </div>
  





    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.lecturer.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Peer-Evaluation-System-main2\resources\views/layouts/lecturer/viewassignmentdetail.blade.php ENDPATH**/ ?>