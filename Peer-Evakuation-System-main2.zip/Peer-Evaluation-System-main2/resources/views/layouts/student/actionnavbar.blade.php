<div class="btn-group pull-right">
            <a href="#" class="btn btn-primary filter-button"><div><i class="material-icons">import_contacts</i></div>Rubric</a>
            </div>

            <div class="row">
            <div class="col-lg-12 col-md-12">
                <div class="card card-nav-tabs ">
                    <div class="card-header" data-background-color="purple">
                        <ul class="nav nav-tabs justify-content-center" >
                            <li class="">
                                <a href="/student/submit">
                                    <i class="material-icons">assignment</i>
                                    Submit
                                    <div class="ripple-container"></div></a>
                                </li>
                                <li class="">
                                    <a href="/student/feedback" >
                                        <i class="material-icons">question_answer</i>
                                        Feedback
                                        <div class="ripple-container"></div></a>
                                    </li>
                                    <li class="">
                                        <a href="/student/evaluate" >
                                            <i class="material-icons">rule</i>
                                            Evaluate
                                            <div class="ripple-container"></div></a>
                                        </li>
                                        <li class="">
                                        <a href="/student/result">
                                            <i class="material-icons">grade</i>
                                            Result
                                            <div class="ripple-container"></div></a>
                                        </li>
                                    </ul>
                                        
                                
                    </div>
                </div>
            </div>    
            </div>            